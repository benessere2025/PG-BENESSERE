
// Future enhancements: analytics, cart, animations.
console.log("Benessere loaded");
